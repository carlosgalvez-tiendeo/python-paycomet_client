# V1ExchangeBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminal** | **int** | Product or terminal Id. | 
**amount** | **str** | Amount to convert | 
**original_currency** | **str** | Currency to convert from | 
**final_currency** | **str** | Currency to convert to | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

