# OrderEditBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscription** | [**V1subscriptionordereditSubscription**](V1subscriptionordereditSubscription.md) |  | 
**payment** | [**V1subscriptionordereditPayment**](V1subscriptionordereditPayment.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

