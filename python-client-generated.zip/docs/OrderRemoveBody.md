# OrderRemoveBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payment** | [**V1subscriptionorderremovePayment**](V1subscriptionorderremovePayment.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

