# V1marketplacesplittransferreversalPayment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminal** | **int** | Product or terminal Id. | 
**order** | **str** | Unique reference for merchant&#x27;s purchase | 
**auth_code** | **str** | Authorization bank code of the transaction (required to execute a split) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

