# IvrSessioncancelBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminal** | **int** | Product or terminal Id. | 
**ivr_provider_id** | **int** | Supplier / IVR integrator code. | 
**ivr_merchant_order** | **str** | Operation reference. It must be unique in each valid transaction. IMPORTANT IN CASE OF SUBSCRIPTIONS Do not include the characters “[“ or “]”, they will be used to recognise the business idUser. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

