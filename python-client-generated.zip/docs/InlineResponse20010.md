# InlineResponse20010

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**name** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**active** | **str** |  | [optional] 
**allow_api_refunds** | **int** |  | [optional] 
**logo_square** | **str** | encoded image of squared logo in base64 format | [optional] 
**logo_landscape** | **str** | encoded image of landscape logo in base64 format | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

