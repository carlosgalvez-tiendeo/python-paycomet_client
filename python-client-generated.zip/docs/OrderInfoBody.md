# OrderInfoBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payment** | [**V1paymentsorderinfoPayment**](V1paymentsorderinfoPayment.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

