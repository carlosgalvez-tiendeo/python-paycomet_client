# InlineResponse20030

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error_code** | **int** | The error code if something went wrong. 0 means no error. | [optional] 
**ivr_response** | **bool** | Indicates the session has been created. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

