# V1formSubscription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_date** | **str** | First day of subscription | [optional] 
**end_date** | **str** | Last day of subscription | [optional] 
**periodicity** | **str** | In days, frequency between purchases | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

