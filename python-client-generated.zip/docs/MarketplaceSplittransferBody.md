# MarketplaceSplittransferBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**submerchant** | [**V1marketplacesplittransferSubmerchant**](V1marketplacesplittransferSubmerchant.md) |  | 
**payment** | [**V1marketplacesplittransferPayment**](V1marketplacesplittransferPayment.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

