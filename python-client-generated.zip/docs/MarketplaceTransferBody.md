# MarketplaceTransferBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**submerchant** | [**V1marketplacesplittransferSubmerchant**](V1marketplacesplittransferSubmerchant.md) |  | 
**payment** | [**V1marketplacetransferPayment**](V1marketplacetransferPayment.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

