# InlineResponse2007

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error_code** | **int** | Error code. | [optional] 
**time** | **str** | PING time to PAYCOMET services | [optional] 
**processor_time** | **str** | PING time to payment processor | [optional] 
**processor_status** | **str** | General processor status (false if unreachable) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

