# InlineResponse20023Dcc

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**session** | **str** |  | [optional] 
**currency** | **str** |  | [optional] 
**currency_iso3** | **str** |  | [optional] 
**currency_name** | **str** |  | [optional] 
**exchange** | **float** |  | [optional] 
**amount** | **str** |  | [optional] 
**_date** | **str** |  | [optional] 
**markup** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

