# InlineResponse20029Operations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**operation_result** | **str** | Operation result OK/KO | [optional] 
**operation_error_code** | **int** | Error code given by PAYCOMET for that operation | [optional] 
**operation_order** | **str** | Order reference | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

