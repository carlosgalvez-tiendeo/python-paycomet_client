# V1subscriptionordereditSubscription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**start_date** | **str** | First day of subscription | 
**end_date** | **str** | Last day of subscription | 
**periodicity** | **str** | In days, time between purchases | 
**active** | **int** | 1 to activate subscription, 0 to desactivate. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

