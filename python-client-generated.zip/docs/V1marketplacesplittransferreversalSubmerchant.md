# V1marketplacesplittransferreversalSubmerchant

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**split_id** | **str** | Identifier for you to receive split payments | 
**amount** | **float** | Amount of the operation | 
**currency** | **str** | Currency of the transaction | 
**split_auth_code** | **str** | Authorization code of the original split transfer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

