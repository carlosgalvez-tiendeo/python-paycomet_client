# InlineResponse2008Invoices

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**account_id** | **int** |  | [optional] 
**shop_id** | **int** |  | [optional] 
**invoice_id** | **int** |  | [optional] 
**invoice_unique_id** | **str** |  | [optional] 
**invoice_type** | **str** |  | [optional] 
**date_created** | **str** |  | [optional] 
**end_time** | **str** |  | [optional] 
**amount** | **float** |  | [optional] 
**currency** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**iban** | **str** |  | [optional] 
**bic** | **str** |  | [optional] 
**owner** | **str** |  | [optional] 
**state** | **int** |  | [optional] 
**last_execution_time** | **str** |  | [optional] 
**error_id** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

