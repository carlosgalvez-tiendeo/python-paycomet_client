# InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_global** | **str** | Total balance in the account | [optional] 
**available** | **str** | Available balance in the account | [optional] 
**deposit** | **str** | Balance withheld in account | [optional] 
**error_code** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

