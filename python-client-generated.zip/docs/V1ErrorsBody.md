# V1ErrorsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminal** | **int** | Product or terminal Id. | 
**error_code** | **int** | Error code given by PAYCOMET. | 
**lang** | **str** | ISO2 code of language. | [optional] [default to 'es']

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

