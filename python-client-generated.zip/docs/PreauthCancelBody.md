# PreauthCancelBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payment** | [**V1paymentsorderpreauthcancelPayment**](V1paymentsorderpreauthcancelPayment.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

