# V1invoicesPayment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terminal** | **int** | Product or terminal Id. | 
**shops_ids** | **list[int]** |  | 
**invoices_ids** | **list[int]** |  | [optional] 
**from_date** | **str** | Start datetime limit (format: YmdHis) | 
**to_date** | **str** | Finish datetime limit (format: YmdHis) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

