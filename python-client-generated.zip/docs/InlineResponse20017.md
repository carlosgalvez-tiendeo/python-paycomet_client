# InlineResponse20017

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | **str** |  | [optional] 
**order** | **str** |  | [optional] 
**amount** | **str** |  | [optional] 
**auth_code** | **str** | Authorization bank code of the transaction (required to execute a return). | [optional] 
**error_code** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

